<?php

$name=$_GET["uname"];
$price=$_GET["price"];
$ph=$_GET["ph"];
$college=$_GET["clg"];
$author=$_GET["author"];

$con=mysql_connect("localhost","root","");
mysql_select_db("books");
$q="insert into hci values('$name','$price','$ph','$college','$author')";
mysql_query($q);
mysql_close($con);

echo "Thank you, your details are updated";

?>