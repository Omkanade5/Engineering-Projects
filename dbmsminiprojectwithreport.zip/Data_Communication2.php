<?php

$con=mysql_connect("localhost","root","");

mysql_select_db("books");

$q="select * from dc";

$result=mysql_query($q);

$no=mysql_num_rows($result);
for($i=0;$i<$no;$i++)
{
$row=mysql_fetch_array($result);
echo"name= $row[0]<br/>";
echo"cost= $row[1]<br/>";
echo"phone= $row[2]<br/>";
echo"college= $row[3]<br/>";
echo"Author= $row[4]<br/><br/><br/>";
}

mysql_close($con);

?>